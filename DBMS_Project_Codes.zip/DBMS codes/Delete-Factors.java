import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
public class deletefactors implements ActionListener{
	private JFrame f=new JFrame("Deletions");
	private JLabel l=new JLabel("");
	private JLabel l1=new JLabel("Enter Factor ID");
	private JLabel l2=new JLabel("Result");
	private JButton b1=new JButton("Delete");
	private JTextField t1=new JTextField();
	private JTextField t2=new JTextField();
	private JTextArea t=new JTextArea();
	private JScrollPane scrollBar=new JScrollPane(t,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
	public deletefactors() {
		f.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		f.setBounds(300,200,720,250);
		Container c=f.getContentPane();
		f.getContentPane().add(l1);
		f.getContentPane().add(l2);
		f.getContentPane().add(scrollBar);   
		scrollBar.setBounds(420,20,250,150);
		f.getContentPane().add(b1);
		f.getContentPane().add(t1);
		f.getContentPane().add(t2);
		l.setBounds(20,30,50,50);
		l1.setBounds(20,20,150,30);
		l1.setOpaque(true);
		l1.setBackground(Color.PINK);
		l2.setBounds(20,60,150,30);
		l2.setOpaque(true);
		l2.setBackground(Color.PINK);
		b1.setBounds(160,120,100,30);
		b1.setFont(new Font("Times New Roman",Font.BOLD,17));
		t1.setBounds(170,20,220,30);
		t2.setBounds(170,60,220,30);
		b1.addActionListener(this);
		c.add(l);
		f.getContentPane().setBackground(Color.PINK);
		t.setEditable(false);
		f.setVisible(true);
	}
	public void actionPerformed(ActionEvent ae){
		String s=new String(ae.getActionCommand());
		if((s).equals("Delete")){
			try{
				t2.setText("Row Deleted");
				Class.forName("oracle.jdbc.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ajay","vasavi");
				Statement stmt=con.createStatement();
				int fid=Integer.parseInt(t1.getText());
				stmt.executeUpdate("delete from factors where fid="+fid+"");
				ResultSet rs=stmt.executeQuery("select * from factors");
				String str=new String();
				while(rs.next())
				     str=str+(rs.getInt(1)+"  "+rs.getString(2)+"\n");
				t.setText(str);
				con.commit();
				con.close();
		}
		catch (Exception e) {
			t2.setText("Error Occured!!");
		}
	  }
	}
	public static void main(String[] args){
		new deletefactors();
	}
}